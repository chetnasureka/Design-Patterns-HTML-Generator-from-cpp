#include"Node.h"
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <stdexcept>
namespace HTML {

Node::Node(){
}
Node& Node::setCloseTag(int value) {
	closeTag = (value > 0) ? 1 : 0;
	return (*this);
}  

Node::Node(const std::string& name)
:NodeTagName(name), NodeContent(""), closeTag(0){
}

Node::Node(const std::string& name, const std::string& content)
:NodeTagName(name), NodeContent(content), closeTag(0) {
}

Node& Node::setAttribute(const std::string& name, const std::string& value) {
	NodeAttributes[name] = value;
	return (*this);
}
Node& Node::appendChild(Node aNode) {
	NodeChildren.push_back(aNode);
	return (*this);
}
Node& Node::setId(const std::string& aId) {
	return setAttribute("id", aId);
}

Node& Node::setClass(const std::string& aClass) {
	return setAttribute("class", aClass);
}
Node& Node::setColor(const std::string& value) {
	NodeStyle["color"] = value;
	return (*this);
}
Node& Node::setBGColor( const std::string& value) {
	NodeStyle["background-color"] = value;
	return (*this);
}
Node& Node::setFont( const std::string& value) {
	NodeStyle["font"] = value;
	return (*this);
}
Node& Node::setBorder( const std::string& value) {
	NodeStyle["border"] = value;
	return (*this);
}
Node& Node::setStyle(const std::string& name, const std::string& value) {
	NodeStyle[name] = value;
	return (*this);
}

std::ostream& Node::print(std::ostream& NodeStream, const size_t indent) const {
	if (!NodeTagName.empty()) {
		NodeStream<<std::string(indent, ' ');
		NodeStream << '<' << NodeTagName;
		for (const auto& kv : NodeAttributes) {
			NodeStream << ' ' << kv.first;
			NodeStream << "=\"" << kv.second << "\"";
		}
		bool first = true;
		bool style = false;
		for (const auto& kv : NodeStyle) {
			if (first){
				style = true;
				first = false;
				NodeStream << " style= \"";
			}
			NodeStream <<kv.first;
			NodeStream << ":" << kv.second << ";";
		}
		if (style){
			NodeStream<<"\"";
		}			
		if (closeTag) {
			NodeStream <<"/>\n";
		}
		else {
			if (NodeContent.empty()) {
				NodeStream << ">\n";
			}
			else {
				NodeStream << '>';
				NodeStream << NodeContent;
			}
			for (auto& child : NodeChildren) {
				child.print(NodeStream, indent + 2);
			}
			if (!NodeChildren.empty()) {
				NodeStream<<std::string(indent, ' ');
			}
			else if (NodeContent.empty()){
				NodeStream<<std::string(indent, ' ');
			}
			NodeStream << "</" << NodeTagName << ">\n";
		}
	}
			
	return NodeStream;
}

std::ostream& operator<<(std::ostream& NodeStream, const Node& aNode) {
	return aNode.print(NodeStream);
}

Button::Button(const std::string& content)
:Node("Button", content){
	setAttribute("type", "button");
}
Button& Button::onClick(const std::string& content) {
	setAttribute("onClick", content);
	return(*this);
}
Button& Button::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}

Div::Div()
:Node("div"){
}

Break::Break()
:Node("br")
{	
	setCloseTag(1);
}
Break& Break::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}

Title::Title(const std::string& content) 
:Node("title", content){
}


H1::H1(const std::string& content) 
:Node("h1", content){
}
H1& H1::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}


H2::H2(const std::string& content) 
:Node("h2", content){
}
H2& H2::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}


H3::H3(const std::string& content) 
:Node("h3", content){
}
H3& H3::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}


H4::H4(const std::string& content) 
:Node("h4", content){
}
H4& H4::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}


H5::H5(const std::string& content) 
:Node("h5", content){
}
H5& H5::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}


H6::H6(const std::string& content) 
:Node("h6", content){
}
H6& H6::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}



Style::Style(const std::string& content) 
:Node("style", content){
}



Head::Head()
:Node("head"){
}
Head& Head::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
}
Head& Head::appendChild(Title aTitle) {
	NodeChildren.push_back(aTitle);
	return (*this);
}
Head& Head::appendChild(Style  aStyle){
	NodeChildren.push_back(aStyle);
	return (*this);
}

Body::Body() :Node("body"){
}
Body& Body::appendChild(Node aNode) {
	NodeChildren.push_back(aNode);
	return (*this);
}


Para::Para(const std::string& content)
: Node("p", content) {
}


Link::Link(const std::string& content, const std::string& url)
:Node("a", content) {
	setAttribute("href", url);
}

Image::Image(const std::string& content, const std::string& url)
	:Node("img", content) {
	setAttribute("href", url);
}

Col::Col()
: Node("td") {
}
Col::Col(const std::string& content)
: Node("td", content) {

}
Col& Col::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}

ColHead::ColHead()
: Node("th") {
}
ColHead::ColHead(const std::string& content)
: Node("th", content) {

}
ColHead& ColHead::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}


Row::Row()
:Node("tr") {
}
Row& Row::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}
Row& Row::appendChild(Col aCol) {
	NodeChildren.push_back(aCol);
	return (*this);
}
Row& Row::appendChild(ColHead aColHead) {
	NodeChildren.push_back(aColHead);
	return (*this);
}


Table::Table()
: Node("table") {
}
Table& Table::appendChild(Node aNode){
	throw std::invalid_argument( "received non compatible child tag type" );
};
Table& Table::appendChild(Row aRow) {
	NodeChildren.push_back(aRow);
	return (*this);
}

Item::Item(const std::string& content)
:Node("li", content) {
}

List::List()
:Node("ul"){
}
List& List::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}
List& List::appendChild(Item item) {
	NodeChildren.push_back(item);
	return (*this);
}

Input::Input()
:Node("input"){
	setCloseTag(1);
}
Input& Input::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}
Input& Input::setName(const std::string& content) {
	setAttribute("name",content);
	return(*this);
}
Input& Input::setType(const std::string& content) {
	setAttribute("type",content);
	return(*this);
}
Input& Input::setValue(const std::string& content) {
	setAttribute("value",content);
	return(*this);
}


Label::Label(const std::string& content)
:Node("label",content){
}
Label& Label::appendChild(Node aNode) {
	throw std::invalid_argument( "received non compatible child tag type" );
}
Label& Label::setFor(const std::string& content) {
	setAttribute("for",content);
	return(*this);
}

Form::Form()
:Node("form"){
}
Form& Form::setMethod(const std::string& content){
	setAttribute("method",content);
	return(*this);
}
Form& Form::setAction(const std::string& content){
	setAttribute("action",content);
	return(*this);
}
Form& Form::appendChild(Input aInput) {
	NodeChildren.push_back(aInput);
	return (*this);
}
Form& Form::appendChild(Label alabel) {
	NodeChildren.push_back(alabel);
	return (*this);
}
Form& Form::appendChild(Break br) {
	NodeChildren.push_back(br);
	return (*this);
}


Document::Document() {
}
void Document::writeFile(const std::string& path) const {
	std::ofstream file(path.c_str());
	file<<*this;
}

std::ostream& operator<<(std::ostream& DocStream, const Document& aDocument) {
	Node doc = Node("html");
	doc.appendChild(aDocument.head);
	doc.appendChild(aDocument.body);
	return doc.print(DocStream);
}	


}

