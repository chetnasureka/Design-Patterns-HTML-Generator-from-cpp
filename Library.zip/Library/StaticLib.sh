#!/bin/bash
echo "Making a static library out of Node.cpp and Node.h "
g++ -std=c++11 -c Node.cpp
ar rcs libNode.a Node.o
echo "Static Library libNode Created"

