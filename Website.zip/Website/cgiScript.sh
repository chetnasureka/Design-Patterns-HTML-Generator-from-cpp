#!/bin/bash
# CGI script
echo "Requires Apache Setup with cgi enabled and appropriate permisssion setup "
echo "Making a static library out of Node.cpp and Node.h "
g++ -std=c++11 -c Node.cpp
ar rcs libNode.a Node.o
echo "Static Library libNode Created"
sudo make -f Make.mk
sudo systemctl start apache2.service
sudo chmod 777 /usr/lib/cgi-bin/*
curl http://127.0.0.1/cgi-bin/hello.cgi 
echo "Go to http://127.0.0.1/cgi-bin/hello.cgi or http://localhost/cgi-bin/hello.cgi"
