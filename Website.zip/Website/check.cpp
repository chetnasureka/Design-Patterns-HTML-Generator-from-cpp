#include "Node.h"
#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <cgicc/CgiDefs.h>
#include <cgicc/Cgicc.h>
#include <cgicc/HTTPHTMLHeader.h>
#include <cgicc/HTMLClasses.h>

using namespace std;
using namespace cgicc;
using namespace HTML;


int main() {
	Cgicc cgi;
	string style = "table, th, td { border: 1px solid black;padding: 5px;}";
	string inputString;
	 Document d;
	d.head.appendChild( Style(style));
	d.head.appendChild( Title("My APP"));
	d.body.appendChild( H2("Ouput from C++ Application"));
	d.body.appendChild( Para("Input Provided:"));
	inputString = cgi("name");
	string res;
	if (!inputString.empty()) {
		res = "String is " + inputString;
		d.body.setBGColor(" #fefbd8");
		d.body.appendChild( Para(res)).appendChild( Break());
		
		int i, count[256] = {0};
		for(i=0; inputString[i] != '\0'; i++){
			count[inputString[i]]++;
		}
		d.body.appendChild( H4("Character Frequency"));
		 Node td =  Table().setId("myTable");
		 td.appendChild(Row().appendChild(ColHead("Character")).appendChild(ColHead("Frequency")));
		for(i=0; i < 256; i++){
			if(count[i] != 0){
				 Node r =  Row().appendChild( Col(string(1,(char)i)));
				r.appendChild( Col(to_string(count[i])));
			        td.appendChild(r);         
			}
		}
		d.body.appendChild(td);
	
	}
	else 
	{
		res = "Not Provided";
		d.body.appendChild( Para(res));
	}
	d.body.appendChild(Break());
	d.body.appendChild(Button("Back").onClick("location.href='./hello.cgi';").setBGColor("coral"));
	std::cout<< "Content-type: text/html\n\n";
	std::cout<<d;

return 0;
}

