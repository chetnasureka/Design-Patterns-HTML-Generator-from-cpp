#include "Node.h"
#include <iostream>
using namespace HTML;
int main() {
	Document d;
	/*try {
	d.head.appendChild(Node("para","hello"));
	}
	catch (std::exception& e){
	 std::cerr << "exception: " << e.what() << "\n"; 
	 }*/
	std::string data = "Any web host that supports CGI (which is likely all of them) will also support websites built with C++.Building a website is practical with C++, especially if performance is critical.A .cpp file that outputs HTML can be compiled to .cgi files and used as web pages.Using our HTML Generator Library provides a clean and easy interface thus aid in writing the .cpp files.C++ files can also be used on the server side to perform validation and logic and results are returned as HTML snippets which can easily be generated with our HTML Generator Library";

	d.head.appendChild(Title("My APP"));
	d.body.setBGColor(" #fefbd8");
	d.body.appendChild(Node("center").appendChild(H1("Demo Application")));
	d.body.appendChild(Para(data).setAttribute("","9")).appendChild(Break());
	d.body.appendChild(H3("Enter String to calculate frequency ").setColor("blue")).appendChild(Break());
	Node in1 = Input().setName("name").setType("text").setId("name");
	Node in2 = Input().setType("submit").setName("submit").setValue("SUBMIT");
	Node frm = Form().setMethod("POST").setAction("check.cgi");
	frm.appendChild(Label("String").setFor("name"));
	frm.appendChild(in1).appendChild(Break()).appendChild(in2).appendChild(Break());
	
	d.body.appendChild(frm);
	d.body.appendChild(Para("Directly Supported Tags Apart from head,body"));
	Node l = List().appendChild(Item("List")).appendChild(Item("Paragraphs"));
	l.appendChild(Item("Table")).appendChild(Item("Link")).appendChild(Item("Form")).appendChild(Item("Div"));
	l.appendChild(Item("all Attributes with some direct available Attributes like Class ID "));
	l.appendChild(Item("all inline style with some direct available Styles like Color,Bgcolor,Font,Border"));
	d.body.appendChild(l);
	d.body.appendChild(Para("Library can be used to write XML"));
	Node tb =  Table();
	Node r1 =  Row().appendChild( Col("Design Patterns")).appendChild( Col("Builder"));
	Node r2 =  Row().appendChild( Col("Project")).appendChild( Col("HTML Generator"));
	tb.appendChild(r1).appendChild(r2);
	d.body.appendChild(tb);
	std::cout<< "Content-type: text/html\n\n";
	std::cout<<d;
	d.writeFile("./new.html");
	return 0;
}

