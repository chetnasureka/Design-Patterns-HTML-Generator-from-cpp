#!/bin/bash
echo "Making a static library out of Node.cpp and Node.h "
g++ -std=c++11 -c Node.cpp -w
ar rcs libNode.a Node.o
echo "Static Library libNode Created"
echo "Reads input form Input.txt which has specification of tags and content  required by the user"
echo "Generates Output.html by parsing through the Input.txt"
g++ -std=c++11 -c Client.cpp -w
g++ -std=c++11 -c gen.cpp -w
g++ -std=c++11 *.o -L. -lNode -w
./a.out

