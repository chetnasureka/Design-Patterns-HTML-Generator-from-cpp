#ifndef GEN_H
#define GEN_H

#include <iostream>
#include <fstream>
#include <string.h>
#include <cstring>
#include <regex> 

void process();
#endif
