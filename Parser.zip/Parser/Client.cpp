#include "gen.h"


int main () 
{
  process();
}

