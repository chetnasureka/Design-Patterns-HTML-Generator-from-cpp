#ifndef HTML_H
#define HTML_H
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <stdexcept>
namespace HTML {
class Node {  
protected:
	std::string NodeTagName;
	std::string NodeContent;
	std::map<std::string, std::string> NodeAttributes;
	std::map<std::string, std::string> NodeStyle;
	std::vector<Node> NodeChildren;
	int closeTag;
	Node();
	Node& setCloseTag(int value);
public:
	Node(const std::string& name);
	Node(const std::string& name, const std::string& content);
	Node& setAttribute(const std::string& name, const std::string& value);
	friend std::ostream& operator<<(std::ostream& NodeStream, const Node& aNode);
	Node& setId(const std::string& aId) ;
	Node& setClass(const std::string& aClass);
	Node& setColor(const std::string& value);
	Node& setBGColor( const std::string& value);
	Node& setFont( const std::string& value);
	Node& setBorder( const std::string& value);
	Node& setStyle(const std::string& name, const std::string& value);
	Node& appendChild(Node aNode);
	std::ostream& print(std::ostream& NodeStream, const size_t indent = 0) const;
};

class Button : public Node {
public:
	Button(const std::string& content);
	Button& onClick(const std::string& content);
	Button& appendChild(Node aNode);
};
class Div : public Node {
public:
	Div();
};
class Break : public Node {
public:
	Break();
	Break& appendChild(Node aNode);
};
class Title : public Node {
public:
	Title(const std::string& content) ;
};
class H1 : public Node {
public:
	H1(const std::string& content);
	H1& appendChild(Node aNode);
};
class H2 : public Node {
public:
	H2(const std::string& content);
	H2& appendChild(Node aNode);
};
class H3 : public Node {
public:
	H3(const std::string& content);
	H3& appendChild(Node aNode);
};
class H4 : public Node {
public:
	H4(const std::string& content);
	H4& appendChild(Node aNode);
};
class H5 : public Node {
public:
	H5(const std::string& content);
	H5& appendChild(Node aNode);
};
class H6 : public Node {
public:
	H6(const std::string& content) ;
	H6& appendChild(Node aNode);
};

class Style : public Node {
public:
	Style(const std::string& content) ;
};

class Head : public Node {
public:
	Head();
	Head& appendChild(Node aNode);
	Head& appendChild(Title aTitle);
	Head& appendChild(Style  aStyle);
};
class Body : public Node {
public:
	Body();
	Body& appendChild(Node aNode);
};

class Para : public Node {
public:
	Para(const std::string& content);
	
};
class Link : public Node {
public:
	Link(const std::string& content, const std::string& url);
};
class Image : public Node {
public:
	Image(const std::string& content, const std::string& url);
};
class Col : public Node {
public:
	Col();
	Col(const std::string& content);
	Col& appendChild(Node aNode);
};
class ColHead : public Node {
public:
	ColHead();
	ColHead(const std::string& content);
	ColHead& appendChild(Node aNode);
};
class Row : public Node {
public:
	Row();
	Row& appendChild(Node aNode);
	Row& appendChild(Col aCol) ;
	Row& appendChild(ColHead aColHead) ;

};

class Table : public Node {
public:
	Table();
	Table& appendChild(Node aNode);
	Table& appendChild(Row aRow);
};
class Item : public Node {
public:
	Item(const std::string& content);
};

class List : public Node {
public:
	List();
	List& appendChild(Node aNode) ;
	List& appendChild(Item item);
};
class Input : public Node {
public:
	Input();
	Input& appendChild(Node aNode) ;
	Input& setName(const std::string& content) ;
	Input& setType(const std::string& content) ;
	Input& setValue(const std::string& content) ;
};
class Label : public Node {
public:
	Label(const std::string& content);
	Label& appendChild(Node aNode) ;
	Label& setFor(const std::string& content);

};
class Form : public Node {
public:
	Form();
	Form& setMethod(const std::string& content);
	Form& setAction(const std::string& content);
	Form& appendChild(Input aInput) ;
	Form& appendChild(Label alabel);
	Form& appendChild(Break br) ;
	
};

class Document 
{
public:
	Head head;
	Body body;
	Document();
	friend std::ostream& operator<<(std::ostream& DocStream, const Document& aDocument);
	void writeFile(const std::string& path) const ;
			
};

}

#endif
