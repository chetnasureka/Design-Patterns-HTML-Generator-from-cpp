#include "gen.h"
#include "Node.h"
#include<cstring>
using namespace HTML;

void process()
{
	std::ifstream myfile_i;
	std::ofstream myfile_o;
	std::string line;
	int i;
	int flag=0;
	char * pch;
	char const *cstr;
	char const headings[11][30]={"Introduction","Acknowledgement","Conclusion","Index","Bibliography","Procedure","Algorithm","Contact us","Login","Address","About us"};
	myfile_i.open ("Input.txt");
	myfile_o.open ("Output.html");
	getline (myfile_i,line);
	cstr = line.c_str();
	std::regex head("(<)(.*)(>)");
	if(regex_match(cstr,head))
		{
			Node head = HTML::Head();
			Node Title= HTML::Title(line);
			head = head.appendChild(Title);
			getline (myfile_i,line);
			cstr = line.c_str();
			myfile_o  << head;

		}
	/*std::regex style("({)(.*)(:)(.*)(;)(})");
	if(regex_match(cstr,style))
	{
			//std::string s("style");
			//HTML::Node y=HTML::Style(line);
			head.appendChild(HTML::Style(line));
			getline (myfile_i,line);
			cstr = line.c_str();	
			
	}
	myfile_o  << head;*/
	Node body=HTML::Body();
	while (!myfile_i.eof())
	{
		flag=0;
		if(line.size()==0)
			{
				std::string br("br");
				HTML::Node y=HTML::Node(br);
				body.appendChild(y);
				getline (myfile_i,line);
				cstr = line.c_str();

			}
        else if(line.size()>0)
			{
				for (i=0;i<11;i++)
					if(strcmp(cstr,headings[i])==0)
						{
							std::string s("h1");
							HTML::Node y=HTML::Node(s,line);
							body.appendChild(y);
							getline (myfile_i,line);
							cstr = line.c_str();
							flag++;
							break;
						}
				if(flag==0)
				{
					std::string s("LINK");
					std::string w("WEBSITE");
					std::regex website("^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9]+\.[a-z]+(\/[a-zA-Z0-9#]+\/?)*$");
					std::regex email("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");
					if(regex_match(cstr,website) || regex_match(cstr,email))
					{	
						if(regex_match(cstr,email))
							s.replace(s.begin(),s.end(),w);
						Node Title= HTML::Link(s,line);
						body.appendChild(Title);
						flag++;
						getline (myfile_i,line);
						cstr = line.c_str();
					}
				}
				if(flag==0)
				{

					std::regex l("(.*)(,)(.*)(,)(.*)(,)(.*)(,)(.*)");
					if(regex_match(cstr,l))
					{
						HTML::Node y=HTML::List();
						char *temp;
						temp = const_cast<char *>(cstr);
						pch = std::strtok (temp,",");
						while (pch != NULL)
  						{
    						std::string s_temp(pch);
    						HTML::Node y2=HTML::Item(s_temp);
    						y.appendChild(y2);
    						pch = strtok (NULL, " ,.-");
  						}
  						getline (myfile_i,line);
						cstr = line.c_str();
						flag++;
  						body.appendChild(y);
					}
				}
				if(flag==0 && line.size()<30)
				{
					if(line.size()>0 && line.size()<10)
					{
						std::string s("h1");
						HTML::Node y=HTML::Node(s,line);
						body.appendChild(y);
						flag++;
					}
			
					if(line.size()>10 && line.size()<20)
					{
						std::string s("h2");
						HTML::Node y=HTML::Node(s,line);
						body.appendChild(y);
						flag++;
					}
					if(line.size()>20 && line.size()<30)
					{
						std::string s("h3");
						HTML::Node y=HTML::Node(s,line);
						body.appendChild(y);
						flag++;
					}
					getline (myfile_i,line);
					cstr = line.c_str();
				}
				if(flag==0)
				{
					std::string s("p");
					HTML::Node y=HTML::Node(s,line);
					body.appendChild(y);
					getline (myfile_i,line);
					cstr = line.c_str();
					flag++;
				}
			}
			
	}
	myfile_o<<body;
    myfile_i.close();
    myfile_o.close();
}
